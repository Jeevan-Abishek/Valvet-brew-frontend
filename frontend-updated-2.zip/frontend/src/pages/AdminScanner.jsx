import { useState, useRef } from 'react';
import { api } from '../lib/api';

// This mocks a scanner with a text input so it works without camera hardware.
// To wire up a real camera scan, drop in a library like 'html5-qrcode' and call
// handleVerify(decodedString) from its onScanSuccess callback instead of the form submit below.

export default function AdminScanner() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState(null); // { access: 'granted' | 'denied', ...}
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);

  async function handleVerify(qrToken) {
    if (!qrToken.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const data = await api.verifyQr(qrToken.trim());
      setResult({ access: 'granted', ...data });
    } catch (err) {
      setResult({ access: 'denied', error: err.message });
    } finally {
      setLoading(false);
      setInput('');
      inputRef.current?.focus();
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    handleVerify(input);
  }

  const isGranted = result?.access === 'granted';
  const isDenied = result?.access === 'denied';

  return (
    <div className="min-h-screen bg-[#0D0B0A] text-[#F5EFE6] font-sans flex flex-col items-center px-6 py-16">
      <p className="text-[#C9A24B] text-xs tracking-[0.3em] uppercase mb-2">Staff Check-in</p>
      <h1 className="font-serif text-3xl mb-10">Verify Reservation</h1>

      <form onSubmit={handleSubmit} className="w-full max-w-md mb-10">
        <label className="block text-xs tracking-[0.2em] uppercase text-[#8A7F72] mb-3">
          Scan or paste QR code string
        </label>
        <input
          ref={inputRef}
          autoFocus
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste decoded QR string here…"
          className="w-full px-4 py-3 rounded-lg bg-[#1A1512] border border-[#241E19] text-[#F5EFE6] placeholder-[#8A7F72] focus:outline-none focus:border-[#C9A24B] mb-3"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="w-full py-3 rounded-full bg-[#C9A24B] text-[#0D0B0A] font-medium disabled:opacity-50 hover:bg-[#D9BB6E] transition-colors"
        >
          {loading ? 'Verifying…' : 'Verify'}
        </button>
      </form>

      {/* Result panel */}
      {result && (
        <div
          className={`w-full max-w-md rounded-2xl border p-8 text-center transition-colors ${
            isGranted ? 'bg-[#4E7A5B]/10 border-[#4E7A5B]' : 'bg-[#8B3A3A]/10 border-[#8B3A3A]'
          }`}
        >
          <div
            className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center text-2xl mb-4 ${
              isGranted ? 'bg-[#4E7A5B] text-[#0D0B0A]' : 'bg-[#8B3A3A] text-[#F5EFE6]'
            }`}
          >
            {isGranted ? '✓' : '✕'}
          </div>
          <h2 className={`font-serif text-2xl mb-2 ${isGranted ? 'text-[#4E7A5B]' : 'text-[#8B3A3A]'}`}>
            {isGranted ? 'Access Granted' : 'Access Denied'}
          </h2>

          {isGranted && result.booking && (
            <div className="mt-6 text-left bg-[#1A1512] rounded-xl p-5 space-y-2">
              <Row label="Guest" value={result.booking.guestName} />
              <Row label="Membership" value={result.booking.membershipTier?.toUpperCase()} />
              <Row label="Table" value={`Table ${result.booking.tableNumber}`} />
              <Row label="Time" value={result.booking.timeSlot} />
              <Row label="Party Size" value={result.booking.partySize} />
            </div>
          )}

          {isDenied && <p className="text-sm text-[#8A7F72] mt-2">{result.error}</p>}
        </div>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-[#8A7F72]">{label}</span>
      <span>{value}</span>
    </div>
  );
}
