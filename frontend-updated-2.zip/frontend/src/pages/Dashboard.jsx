import { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { logout } from '../lib/auth';
import PaymentModal from '../components/PaymentModal';

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
}

function formatSlotLabel(time) {
  const [h, m] = time.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m);
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

function StatusBadge({ booking }) {
  if (booking.status === 'cancelled') {
    return (
      <span className="text-[10px] px-3 py-1 rounded-full uppercase tracking-wide bg-[#8B3A3A]/20 text-[#8B3A3A] border border-[#8B3A3A]">
        Cancelled
      </span>
    );
  }
  if (booking.checkedInAt) {
    return (
      <span className="text-[10px] px-3 py-1 rounded-full uppercase tracking-wide bg-[#4E7A5B]/20 text-[#4E7A5B] border border-[#4E7A5B] flex items-center gap-1">
        ✓ Access Confirmed
      </span>
    );
  }
  return (
    <span className="text-[10px] px-3 py-1 rounded-full uppercase tracking-wide bg-[#C9A24B]/20 text-[#C9A24B] border border-[#C9A24B]">
      Awaiting Check-in
    </span>
  );
}

function PaymentBadge({ booking }) {
  if (booking.paymentStatus === 'paid') {
    return (
      <span className="text-[10px] px-3 py-1 rounded-full uppercase tracking-wide bg-[#4E7A5B]/20 text-[#4E7A5B] border border-[#4E7A5B]">
        Deposit Paid
      </span>
    );
  }
  return (
    <span className="text-[10px] px-3 py-1 rounded-full uppercase tracking-wide bg-[#8B3A3A]/20 text-[#8B3A3A] border border-[#8B3A3A]">
      Deposit Due
    </span>
  );
}

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [payingBooking, setPayingBooking] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    setError('');
    try {
      const [meRes, bookingsRes] = await Promise.all([api.me(), api.getMyBookings()]);
      setUser(meRes.user);
      setBookings(bookingsRes.bookings);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleCancel(id) {
    try {
      await api.cancelBooking(id);
      await loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0D0B0A] flex items-center justify-center text-[#8A7F72]">
        Loading your profile…
      </div>
    );
  }

  const upcoming = bookings.find((b) => b.status === 'confirmed' && !b.checkedInAt);
  const history = bookings.filter((b) => b._id !== upcoming?._id);

  return (
    <div className="min-h-screen bg-[#0D0B0A] text-[#F5EFE6] font-sans">
      <div className="max-w-4xl mx-auto px-6 py-16">
        {/* Profile header */}
        <header className="flex items-center justify-between mb-12">
          <div>
            <p className="text-[#C9A24B] text-xs tracking-[0.3em] uppercase mb-2">Member Profile</p>
            <h1 className="font-serif text-3xl">{user?.fullName}</h1>
            <p className="text-[#8A7F72] text-sm mt-1">
              {user?.membershipTier?.toUpperCase()} MEMBER · {user?.email}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-[#1A1512] border border-[#C9A24B]/40 flex items-center justify-center font-serif text-lg text-[#C9A24B]">
              {user?.fullName?.charAt(0)}
            </div>
            <button
              onClick={() => {
                logout();
                window.location.href = '/';
              }}
              className="text-xs text-[#8A7F72] hover:text-[#8B3A3A] transition-colors underline underline-offset-4"
            >
              Sign out
            </button>
          </div>
        </header>

        {error && (
          <div className="mb-6 px-4 py-3 rounded-lg bg-[#8B3A3A]/20 border border-[#8B3A3A] text-sm">{error}</div>
        )}

        {/* Upcoming reservation - the hero element, styled like a boarding pass */}
        <section className="mb-14">
          <h2 className="text-xs tracking-[0.2em] uppercase text-[#8A7F72] mb-4">Your Upcoming Reservation</h2>

          {upcoming ? (
            <div className="max-w-sm bg-[#1A1512] border border-[#C9A24B]/40 rounded-2xl overflow-hidden">
              <div className="p-6 flex items-center justify-between border-b border-dashed border-[#241E19]">
                <div>
                  <p className="text-[#C9A24B] text-[10px] tracking-[0.25em] uppercase mb-1">The Velvet Brew</p>
                  <h3 className="font-serif text-xl">Table {upcoming.tableNumber}</h3>
                </div>
                <StatusBadge booking={upcoming} />
              </div>

              <div className="px-6 pt-4 flex justify-center">
                <PaymentBadge booking={upcoming} />
              </div>

              <div className="p-6 flex flex-col items-center">
                <img
                  src={upcoming.qrImage}
                  alt="Reservation QR code"
                  className="w-48 h-48 rounded-lg mb-4"
                />

                <div className="grid grid-cols-2 gap-6 w-full text-center mb-2">
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-[#8A7F72] mb-1">Date</p>
                    <p className="text-sm">{formatDate(upcoming.bookingDate)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-[#8A7F72] mb-1">Time</p>
                    <p className="text-sm">{formatSlotLabel(upcoming.timeSlot)}</p>
                  </div>
                </div>
                <p className="text-xs text-[#8A7F72] mt-1">Party of {upcoming.partySize}</p>

                {upcoming.paymentStatus !== 'paid' && (
                  <button
                    onClick={() => setPayingBooking(upcoming)}
                    className="mt-4 px-6 py-2 rounded-full bg-[#C9A24B] text-[#0D0B0A] text-sm font-medium hover:bg-[#D9BB6E] transition-colors"
                  >
                    Pay Deposit
                  </button>
                )}

                <button
                  onClick={() => handleCancel(upcoming._id)}
                  className="mt-6 text-xs text-[#8A7F72] hover:text-[#8B3A3A] transition-colors underline underline-offset-4"
                >
                  Cancel reservation
                </button>
              </div>
            </div>
          ) : (
            <div className="border border-[#241E19] rounded-xl p-8 text-center max-w-sm">
              <p className="text-[#8A7F72] text-sm mb-4">You have no upcoming reservations.</p>
              <a
                href="/book"
                className="inline-block px-6 py-2 rounded-full bg-[#C9A24B] text-[#0D0B0A] text-sm font-medium hover:bg-[#D9BB6E] transition-colors"
              >
                Reserve a Table
              </a>
            </div>
          )}
        </section>

        {/* History */}
        <section>
          <h2 className="text-xs tracking-[0.2em] uppercase text-[#8A7F72] mb-4">Reservation History</h2>
          {history.length === 0 ? (
            <p className="text-[#8A7F72] text-sm">No past reservations yet.</p>
          ) : (
            <div className="divide-y divide-[#241E19] border-t border-b border-[#241E19]">
              {history.map((b) => (
                <div key={b._id} className="flex items-center justify-between py-4">
                  <div>
                    <p className="text-sm">Table {b.tableNumber}</p>
                    <p className="text-xs text-[#8A7F72]">
                      {formatDate(b.bookingDate)} · Party of {b.partySize}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <PaymentBadge booking={b} />
                    <StatusBadge booking={b} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {payingBooking && (
        <PaymentModal
          booking={payingBooking}
          onSuccess={() => {
            setPayingBooking(null);
            loadData();
          }}
          onClose={() => setPayingBooking(null)}
        />
      )}
    </div>
  );
}
