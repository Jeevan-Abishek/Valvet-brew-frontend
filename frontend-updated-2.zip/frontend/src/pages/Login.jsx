import { useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { api } from '../lib/api';

export default function Login() {
  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const next = searchParams.get('next') || '/dashboard';

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const result =
        mode === 'login'
          ? await api.login({ email, password })
          : await api.register({ fullName, email, phone, password });

      localStorage.setItem('noir_ash_token', result.token);
      localStorage.setItem('noir_ash_user', JSON.stringify(result.user));
      navigate(next, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-espresso text-bone font-sans flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <Link to="/" className="font-serif italic text-2xl tracking-wide text-bone">
            Velvet <span className="text-brass not-italic">Brew</span>
          </Link>
          <p className="text-smoke text-xs tracking-[0.25em] uppercase mt-4">
            {mode === 'login' ? 'Welcome back' : 'Join the house'}
          </p>
        </div>

        {/* Mode toggle */}
        <div className="flex mb-8 rounded-full border border-espresso-3 bg-espresso-2 p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`flex-1 py-2 rounded-full text-sm transition-colors ${
              mode === 'login' ? 'bg-brass text-espresso font-medium' : 'text-smoke hover:text-bone'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setError('');
            }}
            className={`flex-1 py-2 rounded-full text-sm transition-colors ${
              mode === 'signup' ? 'bg-brass text-espresso font-medium' : 'text-smoke hover:text-bone'
            }`}
          >
            Create Account
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block text-[11px] tracking-[0.2em] uppercase text-smoke mb-2">
                Full Name
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-espresso-2 border border-espresso-3 text-bone placeholder:text-smoke/50 focus:outline-none focus:border-brass transition-colors"
                placeholder="Rahul Sharma"
              />
            </div>
          )}

          <div>
            <label className="block text-[11px] tracking-[0.2em] uppercase text-smoke mb-2">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-espresso-2 border border-espresso-3 text-bone placeholder:text-smoke/50 focus:outline-none focus:border-brass transition-colors"
              placeholder="you@example.com"
            />
          </div>

          {mode === 'signup' && (
            <div>
              <label className="block text-[11px] tracking-[0.2em] uppercase text-smoke mb-2">
                Phone <span className="normal-case text-smoke/60">(optional)</span>
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-espresso-2 border border-espresso-3 text-bone placeholder:text-smoke/50 focus:outline-none focus:border-brass transition-colors"
                placeholder="+91 98765 43210"
              />
            </div>
          )}

          <div>
            <label className="block text-[11px] tracking-[0.2em] uppercase text-smoke mb-2">Password</label>
            <input
              type="password"
              required
              minLength={mode === 'signup' ? 8 : undefined}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-espresso-2 border border-espresso-3 text-bone placeholder:text-smoke/50 focus:outline-none focus:border-brass transition-colors"
              placeholder="••••••••"
            />
            {mode === 'signup' && (
              <p className="text-[11px] text-smoke mt-1.5">At least 8 characters.</p>
            )}
          </div>

          {error && (
            <div className="px-4 py-3 rounded-lg bg-[#8B3A3A]/20 border border-[#8B3A3A] text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full mt-2 px-6 py-3 rounded-full bg-brass text-espresso font-medium disabled:opacity-50 hover:bg-brass-light transition-colors"
          >
            {submitting ? 'Please wait…' : mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-xs text-smoke mt-8">
          <Link to="/" className="hover:text-brass transition-colors underline underline-offset-4">
            Back to home
          </Link>
        </p>
      </div>
    </div>
  );
}
