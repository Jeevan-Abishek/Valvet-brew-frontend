import Navbar from '../components/Navbar.jsx';
import Hero from '../components/Hero.jsx';
import Pillars from '../components/Pillars.jsx';
import MenuSection from '../components/MenuSection.jsx';
import HowItWorks from '../components/HowItWorks.jsx';
import ReserveBanner from '../components/ReserveBanner.jsx';
import Footer from '../components/Footer.jsx';

export default function Home() {
  return (
    <div className="bg-espresso text-bone font-sans min-h-screen">
      <Navbar />
      <Hero />
      <Pillars />
      <MenuSection />
      <HowItWorks />
      <ReserveBanner />
      <Footer />
    </div>
  );
}
