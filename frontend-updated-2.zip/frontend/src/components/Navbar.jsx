import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { isLoggedIn } from '../lib/auth';

const LINKS = [
  { label: 'Menu', href: '#menu' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'Membership', href: '#membership' },
];

export default function Navbar() {
  const [solid, setSolid] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 48);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    setLoggedIn(isLoggedIn());
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-500 ${
        solid ? 'bg-espresso/90 backdrop-blur-md border-b border-white/5' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-6xl mx-auto flex items-center justify-between px-6 py-5">
        <a href="#top" className="font-serif italic text-2xl tracking-wide text-bone">
          Velvet <span className="text-brass not-italic">Brew</span>
        </a>

        <div className="hidden md:flex items-center gap-10 font-sans text-sm text-bone/80">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} className="hover:text-brass transition-colors">
              {l.label}
            </a>
          ))}
          <Link to={loggedIn ? '/dashboard' : '/login'} className="hover:text-brass transition-colors">
            {loggedIn ? 'My Account' : 'Sign In'}
          </Link>
        </div>

        <Link
          to="/book"
          className="font-sans text-sm px-5 py-2.5 rounded-full border border-brass/60 text-brass hover:bg-brass hover:text-espresso transition-colors"
        >
          Reserve a Table
        </Link>
      </nav>
    </header>
  );
}
