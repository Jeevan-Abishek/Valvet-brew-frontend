export default function Footer() {
  return (
    <footer className="border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 py-10 flex flex-col sm:flex-row items-center justify-between gap-4">
        <span className="font-serif italic text-lg text-bone">
          Velvet <span className="text-brass not-italic">Brew</span>
        </span>
        <p className="font-mono text-xs text-smoke">Reservation-only &middot; one table, one guest, one pass</p>
      </div>
    </footer>
  );
}
