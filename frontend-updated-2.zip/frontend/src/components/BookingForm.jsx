import { useState, useEffect, useMemo } from 'react';
import { api } from '../lib/api';
import PaymentModal from './PaymentModal';

function nextNDays(n) {
  return Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });
}

function formatSlotLabel(time) {
  const [h, m] = time.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m);
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

export default function BookingForm({ onBooked }) {
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [partySize, setPartySize] = useState(2);
  const [availability, setAvailability] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [pendingPaymentBooking, setPendingPaymentBooking] = useState(null);

  const dateOptions = useMemo(() => nextNDays(14), []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    setSelectedTable(null);
    setSelectedSlot(null);

    api
      .getAvailability(selectedDate, partySize)
      .then((data) => !cancelled && setAvailability(data.availability))
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true;
    };
  }, [selectedDate, partySize]);

  async function handleConfirm() {
    if (!selectedTable || !selectedSlot) return;
    setSubmitting(true);
    setError('');
    try {
      const result = await api.createBooking({
        tableNumber: selectedTable.tableNumber,
        bookingDate: selectedDate,
        timeSlot: selectedSlot,
        partySize,
      });
      setPendingPaymentBooking(result.booking);
    } catch (err) {
      setError(err.message);
      const refreshed = await api.getAvailability(selectedDate, partySize).catch(() => null);
      if (refreshed) setAvailability(refreshed.availability);
      setSelectedSlot(null);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0D0B0A] text-[#F5EFE6] font-sans">
      <div className="max-w-5xl mx-auto px-6 py-16 pb-40">
        <header className="mb-12">
          <p className="text-[#C9A24B] text-xs tracking-[0.3em] uppercase mb-3">Reservation</p>
          <h1 className="font-serif text-4xl md:text-5xl">Reserve Your Table</h1>
          <p className="text-[#8A7F72] mt-3 max-w-md">
            Seating is by reservation only. Select a date, party size, and table below.
          </p>
        </header>

        {/* Party size */}
        <section className="mb-10">
          <label className="block text-xs tracking-[0.2em] uppercase text-[#8A7F72] mb-3">Party Size</label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <button
                key={n}
                onClick={() => setPartySize(n)}
                className={`w-11 h-11 rounded-full border text-sm transition-colors ${
                  partySize === n
                    ? 'bg-[#C9A24B] border-[#C9A24B] text-[#0D0B0A]'
                    : 'border-[#241E19] text-[#F5EFE6] hover:border-[#A9843A]'
                }`}
              >
                {n}
              </button>
            ))}
          </div>
        </section>

        {/* Date picker */}
        <section className="mb-10">
          <label className="block text-xs tracking-[0.2em] uppercase text-[#8A7F72] mb-3">Date</label>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {dateOptions.map((d) => {
              const iso = d.toISOString().slice(0, 10);
              const isSelected = iso === selectedDate;
              return (
                <button
                  key={iso}
                  onClick={() => setSelectedDate(iso)}
                  className={`flex-shrink-0 w-16 py-3 rounded-lg border text-center transition-colors ${
                    isSelected
                      ? 'bg-[#C9A24B] border-[#C9A24B] text-[#0D0B0A]'
                      : 'border-[#241E19] hover:border-[#A9843A]'
                  }`}
                >
                  <div className="text-[10px] uppercase tracking-wide">
                    {d.toLocaleDateString('en-US', { weekday: 'short' })}
                  </div>
                  <div className="font-serif text-lg">{d.getDate()}</div>
                </button>
              );
            })}
          </div>
        </section>

        {error && (
          <div className="mb-6 px-4 py-3 rounded-lg bg-[#8B3A3A]/20 border border-[#8B3A3A] text-sm">{error}</div>
        )}

        {/* Table + time slot selection */}
        <section>
          <label className="block text-xs tracking-[0.2em] uppercase text-[#8A7F72] mb-4">
            Available Tables
          </label>

          {loading && <p className="text-[#8A7F72] text-sm">Checking availability…</p>}

          {!loading && availability.length === 0 && (
            <p className="text-[#8A7F72] text-sm">
              No tables seat a party of {partySize} on this date. Try a different date or party size.
            </p>
          )}

          <div className="grid gap-4">
            {availability.map(({ table, slots }) => (
              <div key={table._id} className="border border-[#241E19] rounded-xl p-5 bg-[#1A1512]">
                <div className="flex items-baseline justify-between mb-4">
                  <h3 className="font-serif text-lg">Table {table.tableNumber}</h3>
                  <span className="text-xs text-[#8A7F72] uppercase tracking-wide">
                    {table.tableType} · Seats {table.seatCapacity}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {slots.map((slot) => {
                    const isSelected = selectedTable?.tableNumber === table.tableNumber && selectedSlot === slot.time;
                    return (
                      <button
                        key={slot.time}
                        disabled={!slot.available}
                        onClick={() => {
                          setSelectedTable(table);
                          setSelectedSlot(slot.time);
                        }}
                        className={`px-4 py-2 rounded-full text-sm border transition-colors ${
                          !slot.available
                            ? 'border-[#241E19] text-[#8A7F72]/40 cursor-not-allowed line-through'
                            : isSelected
                            ? 'bg-[#C9A24B] border-[#C9A24B] text-[#0D0B0A]'
                            : 'border-[#241E19] hover:border-[#A9843A]'
                        }`}
                      >
                        {formatSlotLabel(slot.time)}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {selectedTable && selectedSlot && (
        <div className="fixed bottom-0 left-0 right-0 bg-[#1A1512] border-t border-[#241E19] px-6 py-4">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div>
              <p className="text-sm">
                Table {selectedTable.tableNumber} · {formatSlotLabel(selectedSlot)} · Party of {partySize}
              </p>
              <p className="text-xs text-[#8A7F72]">
                {new Date(selectedDate).toLocaleDateString('en-US', {
                  weekday: 'long',
                  month: 'long',
                  day: 'numeric',
                })}
              </p>
            </div>
            <button
              onClick={handleConfirm}
              disabled={submitting}
              className="px-8 py-3 rounded-full bg-[#C9A24B] text-[#0D0B0A] font-medium disabled:opacity-50 hover:bg-[#D9BB6E] transition-colors"
            >
              {submitting ? 'Confirming…' : 'Confirm Reservation'}
            </button>
          </div>
        </div>
      )}

      {pendingPaymentBooking && (
        <PaymentModal
          booking={pendingPaymentBooking}
          onSuccess={(paidBooking) => {
            setPendingPaymentBooking(null);
            onBooked?.({ booking: paidBooking });
          }}
          onClose={() => {
            // Table is still reserved either way — deposit can be paid later from the dashboard.
            const booking = pendingPaymentBooking;
            setPendingPaymentBooking(null);
            onBooked?.({ booking });
          }}
        />
      )}
    </div>
  );
}
