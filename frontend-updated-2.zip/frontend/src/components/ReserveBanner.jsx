import { Link } from 'react-router-dom';
import { useReveal } from '../hooks/useReveal.js';

export default function ReserveBanner() {
  const [ref, visible] = useReveal();

  return (
    <section id="membership" ref={ref} className={`reveal ${visible ? 'is-visible' : ''} max-w-6xl mx-auto px-6 py-28 text-center`}>
      <p className="font-mono text-xs tracking-widest2 uppercase text-brass/70 mb-4">Membership is free. Seats are not unlimited.</p>
      <h2 className="font-serif text-4xl sm:text-5xl text-bone max-w-2xl mx-auto leading-tight">
        Claim your table before someone else does.
      </h2>
      <div className="mt-9">
        <Link
          to="/book"
          className="btn-shimmer relative overflow-hidden inline-block bg-brass text-espresso font-sans font-medium text-sm px-8 py-4 rounded-full hover:bg-brass-light transition-colors"
        >
          Reserve a Table
        </Link>
      </div>
    </section>
  );
}
