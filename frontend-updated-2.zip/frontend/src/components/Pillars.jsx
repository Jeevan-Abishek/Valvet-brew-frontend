import { useReveal } from '../hooks/useReveal.js';

const PILLARS = [
  { label: 'Guaranteed Seating', copy: 'A confirmed booking is a table held for you — never a hope, never a line.' },
  { label: 'Exclusivity by Design', copy: 'Access is gated by reservation, keeping the room calm and quietly paced.' },
  { label: 'Frictionless Entry', copy: 'One signed QR pass at the door. No guest list, no host stand, no wait.' },
  { label: 'Digital Membership', copy: 'Your visits, tier, and upcoming bookings live in a single profile.' },
];

export default function Pillars() {
  const [ref, visible] = useReveal();

  return (
    <section ref={ref} className={`reveal ${visible ? 'is-visible' : ''} border-y border-white/5 bg-espresso-2`}>
      <div className="max-w-6xl mx-auto px-6 py-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
        {PILLARS.map((p) => (
          <div key={p.label} className="border-l border-brass/30 pl-5">
            <span className="block w-1.5 h-1.5 rounded-full bg-brass mb-3" />
            <h3 className="font-serif text-lg text-bone">{p.label}</h3>
            <p className="text-sm text-smoke mt-2 leading-relaxed">{p.copy}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
