import { useEffect, useState } from 'react';
import { useReveal } from '../hooks/useReveal.js';

const STEPS = [
  { label: 'Booked', detail: 'You choose a table, date and time window.' },
  { label: 'Signed', detail: 'The server issues an HMAC-signed pass — it cannot be copied or edited.' },
  { label: 'Scanned', detail: 'Staff scan the pass at the door, no guest list needed.' },
  { label: 'Access Granted', detail: 'Verified in real time: signature, window and single use, all at once.' },
];

export default function HowItWorks() {
  const [ref, visible] = useReveal();
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setActive((a) => (a + 1) % STEPS.length), 2400);
    return () => clearInterval(id);
  }, []);

  return (
    <section
      id="how-it-works"
      ref={ref}
      className={`reveal ${visible ? 'is-visible' : ''} bg-espresso-2 border-y border-white/5`}
    >
      <div className="max-w-6xl mx-auto px-6 py-28 grid md:grid-cols-2 gap-16 items-center">
        {/* The living pass */}
        <div className="flex justify-center">
          <div
            className="pass-cycle relative w-72 rounded-2xl bg-espresso border border-brass/30 shadow-2xl shadow-black/40 p-6"
            style={{ animation: 'passCycle 2.4s ease-in-out infinite' }}
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] tracking-widest2 uppercase text-smoke">Velvet Brew</span>
              <span className="font-mono text-[10px] text-brass">No. 0417</span>
            </div>

            <p className="font-serif text-2xl text-bone mt-6">Table 12</p>
            <p className="font-mono text-xs text-smoke mt-1">Tue &middot; 7:00&ndash;8:30 PM</p>

            <svg className="w-full my-6" height="1">
              <line x1="0" y1="0.5" x2="100%" y2="0.5" className="pass-dash" stroke="#8A7F72" strokeWidth="1" />
            </svg>

            {/* drawn QR-style glyph, purely decorative */}
            <div className="grid grid-cols-6 gap-1 w-24 mx-auto">
              {Array.from({ length: 36 }).map((_, i) => (
                <span
                  key={i}
                  className="aspect-square rounded-[1px]"
                  style={{ background: [3, 4, 9, 12, 13, 17, 20, 24, 27, 30, 31, 35].includes(i) ? '#C9A24B' : 'transparent' }}
                />
              ))}
            </div>

            <p className="text-center font-mono text-[10px] text-smoke mt-4">{STEPS[active].label.toUpperCase()}</p>

            {/* notch cutouts to sell the ticket-stub look */}
            <span className="absolute -left-2.5 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-[#120D0A] border border-brass/30" />
            <span className="absolute -right-2.5 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-[#120D0A] border border-brass/30" />
          </div>
        </div>

        {/* Steps */}
        <div>
          <p className="font-mono text-xs tracking-widest2 uppercase text-brass/70 mb-3">How the pass works</p>
          <h2 className="font-serif text-4xl text-bone mb-10">One booking, four checkpoints.</h2>

          <ol className="space-y-6">
            {STEPS.map((s, i) => (
              <li key={s.label} className="flex gap-4 items-start">
                <span
                  className={`mt-1 w-2.5 h-2.5 rounded-full shrink-0 transition-colors duration-500 ${
                    active === i ? 'bg-brass' : 'bg-white/15'
                  }`}
                />
                <div>
                  <p
                    className={`font-serif text-lg transition-colors duration-500 ${
                      active === i ? 'text-brass' : 'text-bone'
                    }`}
                  >
                    {s.label}
                  </p>
                  <p className="text-sm text-smoke mt-1 leading-relaxed">{s.detail}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
