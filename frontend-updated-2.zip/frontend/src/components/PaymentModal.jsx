import { useState } from 'react';
import { api } from '../lib/api';

function loadRazorpayScript() {
  return new Promise((resolve, reject) => {
    if (window.Razorpay) return resolve();
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = resolve;
    script.onerror = () => reject(new Error('Could not load the payment gateway. Check your connection.'));
    document.body.appendChild(script);
  });
}

function formatRupees(paise) {
  return `₹${(paise / 100).toLocaleString('en-IN')}`;
}

/**
 * PaymentModal
 * Props:
 *  - booking: the booking object just created (needs _id, depositAmount)
 *  - onSuccess: called with the updated (paid) booking
 *  - onClose: called when the user dismisses without paying
 */
export default function PaymentModal({ booking, onSuccess, onClose }) {
  const [status, setStatus] = useState('idle'); // idle | processing | error
  const [error, setError] = useState('');
  const [order, setOrder] = useState(null);

  async function startPayment() {
    setStatus('processing');
    setError('');
    try {
      const created = await api.createPaymentOrder(booking._id);
      setOrder(created);

      if (created.mock) {
        // No real gateway configured on the server — let the user simulate
        // a successful payment so the flow can be built/tested end-to-end.
        setStatus('mock-ready');
        return;
      }

      await loadRazorpayScript();
      const rzp = new window.Razorpay({
        key: created.keyId,
        amount: created.amount,
        currency: created.currency,
        order_id: created.orderId,
        name: 'The Velvet Brew',
        description: `Reservation deposit · Table ${booking.tableNumber}`,
        theme: { color: '#C9A24B' },
        handler: async (response) => {
          await confirmPayment({
            orderId: created.orderId,
            paymentId: response.razorpay_payment_id,
            signature: response.razorpay_signature,
          });
        },
        modal: {
          ondismiss: () => setStatus('idle'),
        },
      });
      rzp.on('payment.failed', () => {
        setStatus('error');
        setError('Payment failed. Please try again.');
      });
      rzp.open();
    } catch (err) {
      setStatus('error');
      setError(err.message);
    }
  }

  async function confirmMockPayment() {
    if (!order) return;
    await confirmPayment({
      orderId: order.orderId,
      paymentId: `mock_pay_${Date.now()}`,
      signature: null,
    });
  }

  async function confirmPayment({ orderId, paymentId, signature }) {
    setStatus('processing');
    try {
      const result = await api.verifyPayment({ bookingId: booking._id, orderId, paymentId, signature });
      onSuccess?.(result.booking);
    } catch (err) {
      setStatus('error');
      setError(err.message);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 px-4">
      <div className="bg-[#1A1512] border border-[#241E19] rounded-2xl max-w-sm w-full p-6 text-[#F5EFE6]">
        <p className="text-[#C9A24B] text-xs tracking-[0.3em] uppercase mb-2">Secure Your Table</p>
        <h2 className="font-serif text-2xl mb-1">Reservation Deposit</h2>
        <p className="text-[#8A7F72] text-sm mb-6">
          Table {booking.tableNumber} · Party of {booking.partySize}
        </p>

        <div className="flex items-baseline justify-between mb-6 pb-6 border-b border-dashed border-[#241E19]">
          <span className="text-sm text-[#8A7F72]">Amount due</span>
          <span className="font-serif text-2xl text-[#C9A24B]">{formatRupees(booking.depositAmount)}</span>
        </div>

        {error && (
          <div className="mb-4 px-4 py-3 rounded-lg bg-[#8B3A3A]/20 border border-[#8B3A3A] text-sm">{error}</div>
        )}

        {status === 'mock-ready' ? (
          <div className="mb-4 px-4 py-3 rounded-lg bg-[#C9A24B]/10 border border-[#C9A24B]/40 text-xs text-[#C9A24B]">
            Test mode: no live payment gateway is configured on this server, so this simulates a successful
            payment. Add RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET to go live.
          </div>
        ) : null}

        <div className="flex gap-3">
          <button
            onClick={onClose}
            disabled={status === 'processing'}
            className="flex-1 py-3 rounded-full border border-[#241E19] text-sm hover:border-[#A9843A] transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={status === 'mock-ready' ? confirmMockPayment : startPayment}
            disabled={status === 'processing'}
            className="flex-1 py-3 rounded-full bg-[#C9A24B] text-[#0D0B0A] text-sm font-medium hover:bg-[#D9BB6E] transition-colors disabled:opacity-50"
          >
            {status === 'processing'
              ? 'Processing…'
              : status === 'mock-ready'
              ? 'Simulate Payment'
              : `Pay ${formatRupees(booking.depositAmount)}`}
          </button>
        </div>
      </div>
    </div>
  );
}
