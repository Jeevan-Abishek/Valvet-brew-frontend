import { Navigate, useLocation } from 'react-router-dom';
import { isLoggedIn } from '../lib/auth';

export default function RequireAuth({ children }) {
  const location = useLocation();

  if (!isLoggedIn()) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/login?next=${next}`} replace />;
  }

  return children;
}
