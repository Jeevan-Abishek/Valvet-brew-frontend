import { Link } from 'react-router-dom';

const PARTICLES = Array.from({ length: 10 }, (_, i) => ({
  id: i,
  left: 8 + ((i * 37) % 84),
  size: 2 + (i % 3),
  delay: (i * 0.7) % 5,
  duration: 6 + (i % 4) * 1.4,
  drift: i % 2 === 0 ? 16 : -16,
}));

export default function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex items-center overflow-hidden pt-24">
      {/* ambient glow */}
      <div
        className="glow-drift pointer-events-none absolute left-1/2 top-1/2 w-[640px] h-[640px] rounded-full blur-3xl opacity-30"
        style={{ background: 'radial-gradient(circle, #C9A24B 0%, transparent 70%)' }}
      />

      {/* floating embers */}
      <div className="pointer-events-none absolute inset-0">
        {PARTICLES.map((p) => (
          <span
            key={p.id}
            className="ember-particle absolute bottom-0 rounded-full bg-brass/70"
            style={{
              left: `${p.left}%`,
              width: p.size,
              height: p.size,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              '--drift': `${p.drift}px`,
            }}
          />
        ))}
      </div>

      <div className="relative max-w-6xl mx-auto w-full px-6 grid md:grid-cols-2 gap-16 items-center">
        {/* Copy */}
        <div>
          <p className="font-mono text-xs tracking-widest2 uppercase text-smoke mb-5">
            No walk-ins &middot; No queues &middot; No exceptions
          </p>
          <h1 className="font-serif text-5xl sm:text-6xl leading-[1.05] text-bone">
            Every seat is
            <br />
            claimed <span className="italic text-brass">before</span>
            <br />
            you arrive.
          </h1>
          <p className="mt-6 text-smoke text-base leading-relaxed max-w-md">
            The Velvet Brew takes no walk-ins. Reserve a table in advance and your
            confirmation becomes a single-use digital pass — shown at the door, honored on sight.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-5">
            <Link
              to="/book"
              className="btn-shimmer relative overflow-hidden inline-block bg-brass text-espresso font-sans font-medium text-sm px-7 py-3.5 rounded-full hover:bg-brass-light transition-colors"
            >
              Reserve a Table
            </Link>
            <a href="#how-it-works" className="font-sans text-sm text-bone/70 hover:text-brass transition-colors">
              See how the pass works &rarr;
            </a>
          </div>

          <dl className="mt-14 grid grid-cols-3 gap-6 max-w-md">
            <div>
              <dt className="font-serif text-2xl text-brass">1</dt>
              <dd className="font-mono text-[11px] uppercase tracking-wide text-smoke mt-1">
                Table per booking
              </dd>
            </div>
            <div>
              <dt className="font-serif text-2xl text-brass">0</dt>
              <dd className="font-mono text-[11px] uppercase tracking-wide text-smoke mt-1">
                Overbooked seats
              </dd>
            </div>
            <div>
              <dt className="font-serif text-2xl text-brass">QR</dt>
              <dd className="font-mono text-[11px] uppercase tracking-wide text-smoke mt-1">
                Signed, single use
              </dd>
            </div>
          </dl>
        </div>

        {/* Line-art cup + steam */}
        <div className="relative flex justify-center">
          <div className="relative">
            {/* steam */}
            <div className="absolute -top-14 left-1/2 -translate-x-1/2 flex gap-3">
              <svg width="10" height="60" className="steam-wisp" style={{ animationDelay: '0s' }}>
                <path d="M5 60 C 12 45, -2 35, 5 20 C 12 8, -2 4, 5 0" stroke="#EDE6D6" strokeOpacity="0.5" strokeWidth="1.5" fill="none" strokeLinecap="round" />
              </svg>
              <svg width="10" height="60" className="steam-wisp" style={{ animationDelay: '1.2s' }}>
                <path d="M5 60 C -2 45, 12 35, 5 20 C -2 8, 12 4, 5 0" stroke="#EDE6D6" strokeOpacity="0.5" strokeWidth="1.5" fill="none" strokeLinecap="round" />
              </svg>
              <svg width="10" height="60" className="steam-wisp" style={{ animationDelay: '2.4s' }}>
                <path d="M5 60 C 12 45, -2 35, 5 20 C 12 8, -2 4, 5 0" stroke="#EDE6D6" strokeOpacity="0.5" strokeWidth="1.5" fill="none" strokeLinecap="round" />
              </svg>
            </div>

            {/* cup + saucer, simple line art */}
            <svg width="260" height="220" viewBox="0 0 260 220" fill="none">
              <ellipse cx="130" cy="196" rx="112" ry="14" stroke="#C9A24B" strokeWidth="1.5" opacity="0.5" />
              <path
                d="M50 78 C 50 130, 72 168, 130 168 C 188 168, 210 130, 210 78 Z"
                fill="#1C1510"
                stroke="#C9A24B"
                strokeWidth="1.5"
              />
              <ellipse cx="130" cy="78" rx="80" ry="16" fill="#3A2A18" stroke="#C9A24B" strokeWidth="1.5" />
              <path
                d="M96 74 C 108 66, 118 82, 130 74 C 142 66, 152 82, 164 74"
                stroke="#E4C989"
                strokeWidth="1.2"
                fill="none"
                strokeLinecap="round"
                opacity="0.8"
              />
              <path
                d="M206 92 C 236 92, 236 138, 206 138"
                stroke="#C9A24B"
                strokeWidth="6"
                fill="none"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
