import { useReveal } from '../hooks/useReveal.js';

const BREWS = [
  { name: 'Cardamom Cortado', notes: 'Espresso, steamed milk, whole cardamom pod', price: '$6' },
  { name: 'Fig Leaf Pour-Over', notes: 'Single origin, washed, notes of fig and honey', price: '$7' },
  { name: 'Smoked Vanilla Latte', notes: 'House vanilla, oat milk, cedar smoke finish', price: '$7' },
  { name: 'Midnight Affogato', notes: 'Double ristretto over dark cocoa gelato', price: '$8' },
];

export default function MenuSection() {
  const [ref, visible] = useReveal();

  return (
    <section id="menu" ref={ref} className={`reveal ${visible ? 'is-visible' : ''} max-w-6xl mx-auto px-6 py-28`}>
      <div className="flex items-end justify-between mb-12">
        <div>
          <p className="font-mono text-xs tracking-widest2 uppercase text-brass/70 mb-3">Featured Brews</p>
          <h2 className="font-serif text-4xl text-bone">A short list, made well.</h2>
        </div>
        <a href="#" className="hidden sm:block font-sans text-sm text-smoke hover:text-brass transition-colors">
          Full menu &rarr;
        </a>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {BREWS.map((b) => (
          <article
            key={b.name}
            className="group relative bg-espresso-2 border border-white/5 rounded-2xl p-6 hover:-translate-y-2 hover:border-brass/40 transition-all duration-300"
          >
            <div className="w-10 h-10 rounded-full border border-brass/40 mb-6 flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-brass group-hover:scale-150 transition-transform duration-300" />
            </div>
            <h3 className="font-serif text-xl text-bone">{b.name}</h3>
            <p className="text-sm text-smoke mt-2 leading-relaxed">{b.notes}</p>
            <p className="font-mono text-sm text-brass mt-6">{b.price}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
